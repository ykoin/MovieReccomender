import os
import pickle
import pandas as pd
import numpy as np
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpRequest

#  Ustawienia �cie�ek do plik�w 
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP_DIR = os.path.join(BASE_DIR, "app")
MODEL_PATH = os.path.join(APP_DIR, "svd_model.pkl")
MOVIES_FILE_PATH = os.path.join(APP_DIR, "movies_metadata.csv")

#  Weryfikacja istnienia plik�w 
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"Error: Model file not found at {MODEL_PATH}")
if not os.path.exists(MOVIES_FILE_PATH):
    raise FileNotFoundError(f"Error: Movie metadata file not found at {MOVIES_FILE_PATH}")

#  �adowanie modelu SVD 
with open(MODEL_PATH, "rb") as f:
    svd = pickle.load(f)
print("SVD model loaded successfully!")

movie_embeddings = svd.components_.T * svd.singular_values_
num_movies = movie_embeddings.shape[0]
print(f"Movie embeddings shape: {movie_embeddings.shape}")

#  �adowanie danych o filmach 
movies_df = pd.read_csv(MOVIES_FILE_PATH, usecols=['id', 'title'], low_memory=False, encoding="utf-8")
movies_df = movies_df.dropna(subset=["title"])
movies_df["id"] = pd.to_numeric(movies_df["id"], errors="coerce")
movies_df = movies_df[movies_df["id"].notna()]
movies_df["id"] = movies_df["id"].astype(int)

if len(movies_df) > num_movies:
    movies_df = movies_df.iloc[:num_movies]
movies_df = movies_df.reset_index(drop=True)

# mapowanie tytu� -> index i index -> tytu�
title_to_index = {title.lower(): idx for idx, title in enumerate(movies_df["title"])}
index_to_title = {idx: title for idx, title in enumerate(movies_df["title"])}

def get_recommendations(movie_titles, top_n=5):
    input_indices = []
    for title in movie_titles:
        idx = title_to_index.get(title.lower())
        if idx is not None:
            input_indices.append(idx)
    if not input_indices:
        return ["Error: No titles found."]

    avg_vector = np.mean(movie_embeddings[input_indices, :], axis=0)
    scores = np.dot(movie_embeddings, avg_vector)
    sorted_indices = np.argsort(scores)[::-1]
    
    recommendations = []
    for idx in sorted_indices:
        if idx in input_indices:
            continue
        recommendations.append(f"{index_to_title[idx]} (score: {scores[idx]:.2f})")
        if len(recommendations) >= top_n:
            break
    return recommendations
 
@csrf_exempt
def index(request: HttpRequest):
    recommendations = []
    if request.method == "POST":
        movies_input = [
            request.POST.get("movie1", "").strip(),
            request.POST.get("movie2", "").strip(),
            request.POST.get("movie3", "").strip(),
            request.POST.get("movie4", "").strip(),
            request.POST.get("movie5", "").strip(),
        ]
        movies_input = [m for m in movies_input if m]
        if movies_input:
            recommendations = get_recommendations(movies_input, top_n=5)
    return render(request, "app/index.html", {"recommendations": recommendations})

def home(request: HttpRequest):
    return render(request, "app/index.html", {"title": "Movie Recommender"})

def about(request: HttpRequest):
    return render(request, "app/about.html", {"title": "About", "message": "Movie recommendation system."})
