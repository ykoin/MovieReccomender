import pandas as pd
import numpy as np
import pickle
import random
from scipy.sparse import csr_matrix
from sklearn.decomposition import TruncatedSVD

data_movies = "movies_metadata.csv"
data_ratings = "ratings_small.csv"
svd_model_path = "svd_model.pkl"

movies_df = pd.read_csv(data_movies, low_memory=False)
ratings_df = pd.read_csv(data_ratings)

# Czyszczenie danych
ratings_df.dropna(inplace=True)
movies_df['id'] = pd.to_numeric(movies_df['id'], errors='coerce')
movies_df = movies_df.dropna(subset=['title'])
valid_movie_ids = set(movies_df['id'].unique())
ratings_df = ratings_df[ratings_df['movieId'].isin(valid_movie_ids)]

# Tworzenie macierzy ocen użytkownik–film
user_movie_matrix = ratings_df.pivot(index='userId', columns='movieId', values='rating').fillna(0)

# Konwersja macierzy do formatu rzadkiego
sparse_matrix = csr_matrix(user_movie_matrix)

# Trenowanie modelu
svd = TruncatedSVD(n_components=20, random_state=42)
reduced_matrix = svd.fit_transform(sparse_matrix)

with open(svd_model_path, "wb") as f:
    pickle.dump(svd, f)

movie_latent_matrix = svd.components_.T * svd.singular_values_

movie_id_to_idx = {movie_id: idx for idx, movie_id in enumerate(user_movie_matrix.columns)}
idx_to_movie_id = {idx: movie_id for movie_id, idx in movie_id_to_idx.items()}

subset_movies_df = movies_df[movies_df['id'].isin(user_movie_matrix.columns)]
movie_id_to_title = dict(zip(subset_movies_df['id'], subset_movies_df['title']))

title_to_movie_id = {title: movie_id for movie_id, title in movie_id_to_title.items()}


def recommend_movies(selected_titles, top_n=5):
    selected_movie_ids = []
    for title in selected_titles:
        movie_id = title_to_movie_id.get(title)
        if movie_id is not None and movie_id in movie_id_to_idx:
            selected_movie_ids.append(movie_id)

    if not selected_movie_ids:
        return pd.DataFrame(columns=['id', 'title', 'similarity_score'])

    selected_indices = [movie_id_to_idx[movie_id] for movie_id in selected_movie_ids]

    selected_latents = movie_latent_matrix[selected_indices, :]

    avg_vector = np.mean(selected_latents, axis=0)

    similarities = movie_latent_matrix.dot(avg_vector)
    sorted_indices = np.argsort(similarities)[::-1]

    # Wykluczenie filmów, które zostały już wybrane
    recommended_indices = [idx for idx in sorted_indices if idx_to_movie_id[idx] not in selected_movie_ids]
    recommended_indices = recommended_indices[:top_n]

    recommended_movie_ids = [idx_to_movie_id[idx] for idx in recommended_indices]

    rec_data = []
    for movie_id in recommended_movie_ids:
        title = movie_id_to_title.get(movie_id)
        sim_score = similarities[movie_id_to_idx[movie_id]]
        rec_data.append({"id": movie_id, "title": title, "similarity_score": sim_score})

    return pd.DataFrame(rec_data)


# Generowanie przykładowych zestawów filmów i wyświetlenie rekomendacji
random.seed(42)
num_sets = 5
sample_movie_sets = []

valid_titles = list(movie_id_to_title.values())

for i in range(num_sets):
    sample_set = random.sample(valid_titles, 5)
    sample_movie_sets.append(sample_set)

recommendation_results = {}
for idx, sample_set in enumerate(sample_movie_sets):
    recommendation_results[idx + 1] = recommend_movies(sample_set)

for idx, sample_set in enumerate(sample_movie_sets):
    print(f"\nZestaw {idx + 1} - Wybrane filmy: {sample_set}")
    print(recommendation_results[idx + 1])
